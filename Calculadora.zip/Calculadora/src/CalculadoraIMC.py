import tkinter as tk
from tkinter import messagebox, PhotoImage
import csv

def calcularImc():
    try:
        peso = float(entryPeso.get())
        altura = float(entryAltura.get())
        edad = int(spinboxEdad.get())
        sexo = varSexo.get()
        
        if sexo == 'Hombre':
            ks = 1.0
        elif sexo == 'Mujer':
            ks = 1.1

        ka = 1 + 0.01 * (edad - 25)
        imc = peso / (altura ** 2)
        imcAjustado = imc * ks * ka
        
        clasificacion = clasificarImc(imcAjustado)
        labelResultado.config(text=f"TU IMC ES:   {imcAjustado:.2f} ({clasificacion})")
        
    except ValueError:
        messagebox.showerror("Error", "Por favor ingrese datos válidos")

def clasificarImc(imcAjustado):
    if imcAjustado < 18.5:
        return "Bajo peso"
    elif 18.5 <= imcAjustado < 25:
        return "Normal"
    elif 25 <= imcAjustado < 30:
        return "Sobrepeso"
    elif 30 <= imcAjustado < 35:
        return "Obesidad I"
    elif 35 <= imcAjustado < 40:
        return "Obesidad II"
    else:
        return "Obesidad III"

def guardarDatos():
    nombre = entryNombre.get()
    
    if not nombre:
        messagebox.showerror("Error", "No hay datos que guardar")
        return
    
    try:
        peso = float(entryPeso.get())
        altura = float(entryAltura.get())
        edad = int(spinboxEdad.get())
        sexo = varSexo.get()
        
        if sexo == 'Hombre':
            ks = 1.0
        elif sexo == 'Mujer':
            ks = 1.1
        
        ka = 1 + 0.01 * (edad - 25)
        imc = peso / (altura ** 2)
        imcAjustado = imc * ks * ka
        clasificacion = clasificarImc(imcAjustado)
        
        nombreArchivo = f"{nombre}.csv"
        with open(nombreArchivo, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(['Nombre', 'Peso', 'Altura', 'Edad', 'Sexo', 'IMC Ajustado', 'Clasificación'])
            writer.writerow([nombre, peso, altura, edad, sexo, imcAjustado, clasificacion])
        
        messagebox.showinfo("Éxito", f"Datos guardados en {nombreArchivo}")
    except ValueError:
        messagebox.showerror("Error", "Por favor ingrese valores válidos")

root = tk.Tk()
root.title("Calculadora de IMC")
root.configure(bg="#C1E1C1")

backgroundImage = PhotoImage(file="../images/FondoIMC0.png")
backgroundLabel = tk.Label(root, image=backgroundImage)
backgroundLabel.place(relwidth=1, relheight=1)

tk.Label(root, text="IMC CALCULADORA", bg="#C3FDB8", fg="brown", font=("Times New Roman", 17, "bold")).place(relx=0.5, rely=0.1, anchor="center")

imgCalcular = PhotoImage(file="../images/Calcular.png")
imgGuardar = PhotoImage(file="../images/Guardar.png")

fuente = ("Times New Roman", 10)

tk.Label(root, text="Nombre:", bg="white", fg="brown", font=fuente).place(relx=0.39, rely=0.2, anchor="e")
entryNombre = tk.Entry(root, bg="#D8D8D8", width=12, font=fuente)
entryNombre.place(relx=0.42, rely=0.2, anchor="w")

tk.Label(root, text="Peso (kg):", bg="white", fg="brown", font=fuente).place(relx=0.39, rely=0.3, anchor="e")
entryPeso = tk.Entry(root, bg="#D8D8D8", width=6, font=fuente)
entryPeso.place(relx=0.42, rely=0.3, anchor="w")

tk.Label(root, text="Altura (m):", bg="white", fg="brown", font=fuente).place(relx=0.39, rely=0.4, anchor="e")
entryAltura = tk.Entry(root, bg="#DCDCDC", width=6, font=fuente)
entryAltura.place(relx=0.42, rely=0.4, anchor="w")

tk.Label(root, text="Edad:", bg="white", fg="brown", font=fuente).place(relx=0.39, rely=0.5, anchor="e")
spinboxEdad = tk.Entry(root, bg="#DCDCDC", width=6, font=fuente)
spinboxEdad.place(relx=0.42, rely=0.5, anchor="w")

tk.Label(root, text="Sexo:", bg="white", fg="brown", font=fuente).place(relx=0.39, rely=0.59, anchor="e")

varSexo = tk.StringVar(value="Hombre")
tk.Radiobutton(root, text="Masculino", variable=varSexo, value="Hombre", bg="#DCDCDC", fg="brown", font=fuente).place(relx=0.42, rely=0.59, anchor="w")
tk.Radiobutton(root, text="Femenino", variable=varSexo, value="Mujer", bg="#DCDCDC", fg="brown", font=fuente).place(relx=0.42, rely=0.64, anchor="w")

buttonCalcular = tk.Button(root, image=imgCalcular, command=calcularImc, bg="#BEEDAA", bd=9, width=150, height=150)
buttonCalcular.place(relx=0.33, rely=0.72, anchor="center")

buttonGuardar = tk.Button(root, image=imgGuardar, command=guardarDatos, bg="#BEEDAA", bd=9, width=150, height=150)
buttonGuardar.place(relx=0.6, rely=0.72, anchor="center")

labelResultado = tk.Label(root, text="RESULTADO DEL IMC: ", bg="#C3FDB8", fg="blue", font=fuente)
labelResultado.place(relx=0.5, rely=0.8, anchor="center")

root.mainloop()
